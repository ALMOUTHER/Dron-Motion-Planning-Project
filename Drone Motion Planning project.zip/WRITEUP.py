Writeup project2 second**try

rubrics first point ((Explain the Starter Code))

planning_utils code folder:
1-	Define to python how to create grid
2-	Set class for motion called action
3-	Define valid_actions function to delete the possibilities for drone to choose action on obstacle or out the map
4-	Define A* and heuristic systems to choose the best action 
 
$$ plan_path() function:
1-	Change state to PLANNING
2-	Choose TARGET_ALTITUDE 
3-	Choose SAFETY_DISTANCE
4-	Set self-target-position [2] to equal TARGET_ALTITUDE 
5-	Set home position to be self-longitude and self-latitude
6-	Change global position to local
7-	Read in obstacle map
8-	Define a grid for a particular altitude and safety margin around obstacles
9-	 Set start point
10-	Ask the user to choose goal point
11-	Planning a path using A* system and heuristic system plus calculation the cost
12-	Use prune path method to minimize the steps and make the path as smooth as possible
13-	Set self-waypoints
14-	send waypoints to sim (this is just for visualization of waypoints)
\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
rubrics second points ((Implementing Your Path Planning Algorithm))

rubrics(A) ***Here how I set home position:

self.set_home_position(self._longitude, self._latitude, 0)

rubrics(B) ***Here how I change global position to local:

global_to_local(self.global_position, self.global_home)

rubrics(C):** I start from my current position by:

self.set_home_position(self._longitude, self._latitude, 0)

rubrics(D) *** I change the goal point to be the user input:
    
        to_latitude = input('Choose latitude ')
        to_longitude = input('Choose longitude ')
        longitude = -North_offset + int(to_longitude)
        latitude = -east_offset + int(to_latitude)
        grid_goal = (longitude, latitude)
    

rubrics(E) *** I add diagonal motion in A* system by cost sqrt(2) and on Action class on planning_utils code folder:
    
    ES = (1, 1, np.sqrt(2))
    EN = (-1, 1, np.sqrt(2))
    WS = (1, -1, np.sqrt(2))
    WN = (-1, -1, np.sqrt(2))

rubrics(F) *** I try to produce Purned path system by collinearity_check and four2two and four2_minestwo and four2four:
        def point(p):
            return np.array([p[0], p[1], 1.]).reshape(1, -1)

        def collinearity_check(p1, p2, p3, epsilon=1e-6):   
            m = np.concatenate((p1, p2, p3), 0)
            det = np.linalg.det(m)
            return abs(det) < epsilon

        def four2two(p1, p2, p3):    
            return p1[0][0] == p2[0][0] - 1 or p1[0][0] == p2[0][0] - 2 or p1[0][0] == p2[0][0] - 3 or p1[0][1] == p2[0][1] - 1 or p1[0][1] == p2[0][1] - 2 or p1[0][1] == p2[0][1] - 3 
        def four2_minestwo(p1, p2, p3):
            return p1[0][0] == p2[0][0] + 1 or p1[0][0] == p2[0][0] + 2 or p1[0][0] == p2[0][0] + 3 or p1[0][1] == p2[0][1] + 1 or p1[0][1] == p2[0][1] + 2 or p1[0][1] == p2[0][1] + 3 
        def four2four(p1, p2, p3):
            return p1[0][0] == p2[0][0] + 4 or p1[0][1] == p2[0][1] + 4 or p1[0][0] == p2[0][0] - 4 or p1[0][1] == p2[0][1] - 4 
        
        def prune_path(path):
            pruned_path = [p for p in path]        
            i = 0
            while i != len(pruned_path) - 2:
                p1 = point(pruned_path[i])
                p2 = point(pruned_path[i+1])
                p3 = point(pruned_path[i+2])
                if collinearity_check(p1, p2, p3):
                    pruned_path.remove(pruned_path[i+1])
                elif four2two(p1, p2, p3):
                    pruned_path.remove(pruned_path[i+1])
                elif four2_minestwo(p1, p2, p3):
                    pruned_path.remove(pruned_path[i+1])
                elif p3[0][1] == p2[0][1] + 3 or p3[0][0] == p2[0][0] + 3:
                    pruned_path.remove(pruned_path[i+1])
                elif p3[0][1] == p2[0][1] - 3 or p3[0][0] == p2[0][0] - 3:
                    pruned_path.remove(pruned_path[i+1])
                elif collinearity_check(p1, p2, p3):
                    pruned_path.remove(pruned_path[i+1])
                elif four2four(p1, p2, p3):
                    pruned_path.remove(pruned_path[i+1])
                else:
                    i += 1

            return pruned_path
\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\

rubrics third point ((Executing the flight)):
    
    The drone is going from start to goal with margin 5 meter from most of the building 
    
    
    
    
    
    
    
    

